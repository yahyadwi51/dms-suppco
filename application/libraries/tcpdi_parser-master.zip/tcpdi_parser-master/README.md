tcpdi_parser
============

Parser for use with TCPDI, based on TCPDF_PARSER.  Supports PDFs up to v1.7.

See [pauln/tcpdi](https://github.com/pauln/tcpdi) for installation and usage instructions.
